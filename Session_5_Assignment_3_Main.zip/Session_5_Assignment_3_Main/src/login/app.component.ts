import { Component } from '@angular/core';
//Adding component
@Component({
  selector: 'my-app-component',
  templateUrl: './app.component.html'
})
export class LoginComponent {

}
